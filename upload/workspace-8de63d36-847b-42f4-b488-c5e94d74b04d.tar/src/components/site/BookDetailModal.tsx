"use client";

import { useEffect, useRef, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "@/components/ui/dialog";
import {
  ExternalLink,
  BookOpen,
  Calendar,
  Tag,
  Share2,
  Check,
  Copy,
  Shuffle,
} from "lucide-react";
import type { Book } from "@/data/books";
import { BookCover } from "./BookCover";
import { cn } from "@/lib/utils";

type BookDetailModalProps = {
  book: Book | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

/** Build the shareable URL for a book — points to the per-book route. */
function bookShareUrl(book: Book) {
  const slug = book.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const base = typeof window !== "undefined" ? window.location.origin : "https://lewosteen.example.com";
  return `${base}/book/${slug}`;
}

export function BookDetailModal({ book, open, onOpenChange }: BookDetailModalProps) {
  const [shareOpen, setShareOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const shareRef = useRef<HTMLDivElement | null>(null);

  // Close the share menu on outside click / Escape.
  useEffect(() => {
    if (!shareOpen) return;
    const onDown = (e: MouseEvent) => {
      if (shareRef.current && !shareRef.current.contains(e.target as Node)) {
        setShareOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setShareOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [shareOpen]);

  // No effect needed — share state is reset via the `key` prop on the
  // DialogContent wrapper (remounts per book) + the onOpenChange handler.

  if (!book) return null;

  const shareUrl = bookShareUrl(book);
  const shareText = `${book.title} by Lew Osteen — ${book.genre}`;
  const ogImageUrl = `${typeof window !== "undefined" ? window.location.origin : ""}/api/og?book=${encodeURIComponent(book.title)}`;

  const onShare = (target: "copy" | "twitter" | "facebook" | "whatsapp" | "reddit") => {
    const fullUrl = encodeURIComponent(shareUrl);
    const fullText = encodeURIComponent(shareText);
    if (target === "copy") {
      try {
        navigator.clipboard?.writeText(shareUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 1800);
      } catch {
        /* ignore */
      }
      return;
    }
    let winUrl = "";
    if (target === "twitter") winUrl = `https://twitter.com/intent/tweet?text=${fullText}&url=${fullUrl}`;
    else if (target === "facebook") winUrl = `https://www.facebook.com/sharer/sharer.php?u=${fullUrl}`;
    else if (target === "whatsapp") winUrl = `https://wa.me/?text=${fullText}%20${fullUrl}`;
    else if (target === "reddit") winUrl = `https://www.reddit.com/submit?url=${fullUrl}&title=${fullText}`;
    window.open(winUrl, "_blank", "noopener,noreferrer");
    setShareOpen(false);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) {
          // Reset share state when closing.
          setShareOpen(false);
          setCopied(false);
        }
        onOpenChange(o);
      }}
    >
      <DialogContent
        key={book.title}
        className="max-w-3xl bg-[#15120F] border-gold/40 text-cream p-0 overflow-hidden max-h-[92vh] overflow-y-auto"
        aria-describedby={book ? `book-desc-${book.title}` : undefined}
      >
        <div className="grid sm:grid-cols-[0.8fr_1.2fr]">
          {/* LEFT: cover */}
          <div className="relative bg-deep p-6 sm:p-8 flex items-center justify-center border-b sm:border-b-0 sm:border-r border-gold-soft/30">
            <div className="relative w-[200px] sm:w-[230px]">
              {/* glow */}
              <div
                className="absolute -inset-5 rounded-full blur-2xl opacity-40"
                style={{ background: "radial-gradient(circle, rgba(217,178,107,0.4), transparent 70%)" }}
                aria-hidden="true"
              />
              <div className="book-3d relative">
                <BookCover
                  src={book.cover}
                  alt={`Cover of ${book.title} by Lew Osteen`}
                  title={book.title}
                  subtitle={book.subtitle}
                />
              </div>
            </div>
          </div>

          {/* RIGHT: details */}
          <div className="p-6 sm:p-8">
            <DialogHeader className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gold/10 border border-gold/40 text-gold font-ui text-[0.58rem] uppercase tracking-widest-2">
                  <Tag className="h-3 w-3" />
                  {book.genre}
                </span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-deep/60 border border-gold-soft text-muted-warm font-ui text-[0.58rem] uppercase tracking-widest-2">
                  <Calendar className="h-3 w-3" />
                  {book.year}
                </span>
              </div>
              <DialogTitle className="font-heading uppercase text-cream text-2xl sm:text-3xl tracking-wide leading-tight">
                {book.title}
              </DialogTitle>
              {book.subtitle && (
                <DialogDescription className="font-body italic text-gold/90 text-base mt-1">
                  {book.subtitle}
                </DialogDescription>
              )}
            </DialogHeader>

            <div
              id={`book-desc-${book.title}`}
              className="font-body text-cream/85 leading-relaxed text-[0.95rem] space-y-3 mb-6"
            >
              <p>{book.description}</p>
              <p className="text-muted-warm text-[0.85rem] italic">
                A work by Lew Osteen — award-winning author of epic westerns,
                historical fiction, and apocalyptic prophecy.
              </p>
            </div>

            {/* Action row: Amazon + Share menu + Close */}
            <div className="flex flex-wrap items-center gap-3">
              <a
                href={book.amazonUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-gold inline-flex items-center justify-center gap-2"
              >
                View on Amazon
                <ExternalLink className="h-4 w-4" />
              </a>

              {/* Share menu (per-book OG image) */}
              <div className="relative" ref={shareRef}>
                <button
                  onClick={() => setShareOpen((v) => !v)}
                  aria-expanded={shareOpen}
                  aria-haspopup="menu"
                  aria-label={`Share ${book.title}`}
                  className="inline-flex items-center gap-2 px-4 py-3 rounded-sm border border-gold/50 text-gold hover:text-gold-bright hover:border-gold hover:bg-gold/5 font-ui text-[0.7rem] uppercase tracking-widest-2 transition-all"
                >
                  <Share2 className="h-4 w-4" />
                  Share
                </button>
                {shareOpen && (
                  <div
                    role="menu"
                    className="absolute left-0 top-full mt-2 z-20 w-52 bg-deep border border-gold-soft rounded-sm shadow-xl overflow-hidden animate-[fadeIn_0.15s_ease-out]"
                  >
                    {/* Per-book OG preview thumbnail */}
                    <div className="px-3 pt-3 pb-2 border-b border-gold-soft/50">
                      <div className="font-ui text-[0.54rem] uppercase tracking-widest-2 text-gold/70 mb-1.5">
                        Social card preview
                      </div>
                      <img
                        src={ogImageUrl}
                        alt={`Social share card for ${book.title}`}
                        className="w-full h-auto rounded-sm border border-gold-soft/40"
                        loading="lazy"
                      />
                    </div>
                    <button
                      role="menuitem"
                      onClick={() => onShare("twitter")}
                      className="flex items-center gap-3 w-full px-4 py-2.5 text-left font-ui text-[0.66rem] uppercase tracking-widest-2 text-cream/80 hover:text-gold-bright hover:bg-gold/10 transition-colors"
                    >
                      <span className="text-gold/70 w-4 text-center">𝕏</span>
                      Post on X
                    </button>
                    <button
                      role="menuitem"
                      onClick={() => onShare("facebook")}
                      className="flex items-center gap-3 w-full px-4 py-2.5 text-left font-ui text-[0.66rem] uppercase tracking-widest-2 text-cream/80 hover:text-gold-bright hover:bg-gold/10 transition-colors"
                    >
                      <span className="text-gold/70 w-4 text-center">f</span>
                      Share on Facebook
                    </button>
                    <button
                      role="menuitem"
                      onClick={() => onShare("whatsapp")}
                      className="flex items-center gap-3 w-full px-4 py-2.5 text-left font-ui text-[0.66rem] uppercase tracking-widest-2 text-cream/80 hover:text-gold-bright hover:bg-gold/10 transition-colors"
                    >
                      <span className="text-gold/70 w-4 text-center">✆</span>
                      Send via WhatsApp
                    </button>
                    <button
                      role="menuitem"
                      onClick={() => onShare("reddit")}
                      className="flex items-center gap-3 w-full px-4 py-2.5 text-left font-ui text-[0.66rem] uppercase tracking-widest-2 text-cream/80 hover:text-gold-bright hover:bg-gold/10 transition-colors"
                    >
                      <span className="text-gold/70 w-4 text-center">ⓡ</span>
                      Post to Reddit
                    </button>
                    <button
                      role="menuitem"
                      onClick={() => onShare("copy")}
                      className="flex items-center gap-3 w-full px-4 py-2.5 text-left font-ui text-[0.66rem] uppercase tracking-widest-2 text-cream/80 hover:text-gold-bright hover:bg-gold/10 transition-colors border-t border-gold-soft/50"
                    >
                      <span className="text-gold/70 w-4 text-center">
                        {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                      </span>
                      {copied ? "Link copied" : "Copy link"}
                    </button>
                  </div>
                )}
              </div>

              <a
                href={bookShareUrl(book)}
                className="btn-outline-gold inline-flex items-center justify-center gap-2"
              >
                <BookOpen className="h-4 w-4" />
                Open Page
              </a>

              <DialogClose asChild>
                <button className="font-ui text-[0.66rem] uppercase tracking-widest-2 text-muted-warm hover:text-gold-bright transition-colors px-3 py-3">
                  Close
                </button>
              </DialogClose>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
