// ============================================================
// LEW OSTEEN — BOOK DATA (Bookshelf carousel)
// Edit this array to add / update / remove books.
// Each book: { title, subtitle, year, description, cover, amazonUrl }
// "The Pyramids of Nod" is NOT here — it has its own Coming Soon section.
// ============================================================

export type Book = {
  title: string;
  subtitle?: string;
  year: string;
  description: string;
  cover: string;
  amazonUrl: string;
  genre: Genre;
};

export type Genre =
  | "Western"
  | "Historical Fiction"
  | "Thriller"
  | "Apocalyptic"
  | "Sci-Fi"
  | "Children's";

export const GENRES: Genre[] = [
  "Western",
  "Historical Fiction",
  "Thriller",
  "Apocalyptic",
  "Sci-Fi",
  "Children's",
];

// Fallback Amazon search link generator (always lands on the right results)
const searchUrl = (title: string) =>
  `https://www.amazon.com/s?k=${encodeURIComponent("Lew Osteen " + title)}&i=stripbooks`;

export const AUTHOR_AMAZON_URL =
  "https://www.amazon.com/stores/author/B073YGNKC3/about?_encoding=UTF8&ref_=aufs_ap_ahdr_dsk_aa&pd_rd_w=StdWR&content-id=amzn1.sym.7e190e19-9f6f-4df8-807a-5a7608594741&pf_rd_p=7e190e19-9f6f-4df8-807a-5a7608594741&pf_rd_r=131-8533357-0552420&pd_rd_wg=YBTh1&pd_rd_r=3cbbaffd-6ffd-49d3-9d0c-fb76ffb9429d";

export const books: Book[] = [
  {
    title: "The Judgement",
    subtitle: "Mystery · Thriller · Suspense",
    year: "2024",
    description:
      "582 pages. Satan knows what awaits him on God's Judgement Day. Publisher: Orion Publishing.",
    cover: "/images/books/the-judgement.jpg",
    amazonUrl: "https://www.amazon.com/Judgement-Lew-Osteen-ebook/dp/B0DQRCZPSY",
    genre: "Thriller",
  },
  {
    title: "The Cure",
    subtitle: "Latest Release",
    year: "2025",
    description:
      "The newest novel from Lew Osteen — a tense, thought-provoking thriller.",
    cover: "/images/books/the-cure.jpg",
    amazonUrl: searchUrl("The Cure"),
    genre: "Thriller",
  },
  {
    title: "The Apocalypse Cometh",
    subtitle: "Apocalyptic Prophecy Fiction",
    year: "2023",
    description:
      "276 pages of apocalyptic prophecy fiction. ISBN 979-8890219701.",
    cover: "/images/books/the-apocalypse-cometh.jpg",
    amazonUrl: "https://www.amazon.com/Apocalypse-Cometh-Lew-Osteen/dp/B0CQMTWJ4X",
    genre: "Apocalyptic",
  },
  {
    title: "Wake Up World!",
    subtitle: "Apocalypse Cometh Prophecy, Book Two",
    year: "2023",
    description:
      "Can You Not Heed the Signs of the Times? — the second book in the Apocalypse Cometh prophecy series.",
    cover: "/images/books/wake-up-world.jpg",
    amazonUrl: searchUrl("Wake Up World"),
    genre: "Apocalyptic",
  },
  {
    title: "A Yellow Cotton Dress",
    subtitle: "Novel",
    year: "2003",
    description:
      "A 428-page hardcover novel. ISBN-10 0971643741.",
    cover: "/images/books/a-yellow-cotton-dress.jpg",
    amazonUrl: "https://www.amazon.com/Yellow-Cotton-Dress-Lew-Osteen/dp/0971643741",
    genre: "Historical Fiction",
  },
  {
    title: "Six Notch Road",
    subtitle: "The Joshua Trail Trilogy, Book 1",
    year: "2017",
    description:
      "An epic western in the tradition of The Outlaw Josey Wales and The Searchers.",
    cover: "/images/books/six-notch-road.jpg",
    amazonUrl: "https://www.amazon.com/dp/1547221453",
    genre: "Western",
  },
  {
    title: "The Joshua Trail",
    subtitle: "The Joshua Trail Trilogy, Book 2",
    year: "2017",
    description:
      "The second book of the western trilogy. ISBN-10 1548152528.",
    cover: "/images/books/the-joshua-trail.jpg",
    amazonUrl: "https://www.amazon.com/dp/1548152528",
    genre: "Western",
  },
  {
    title: "A Season of Reckoning",
    subtitle: "The Joshua Trail Trilogy, Book 3",
    year: "2017",
    description:
      "The third and final book of the trilogy. ISBN-10 1548151939.",
    cover: "/images/books/a-season-of-reckoning.jpg",
    amazonUrl: "https://www.amazon.com/dp/1548151939",
    genre: "Western",
  },
  {
    title: "An Old Familiar Rain",
    subtitle: "Murder · Mystery · Spy vs. Spy",
    year: "2017",
    description:
      "Murder, mystery and spy-vs-spy aboard the Trans-Siberian Express.",
    cover: "/images/books/an-old-familiar-rain.jpg",
    amazonUrl: searchUrl("An Old Familiar Rain"),
    genre: "Thriller",
  },
  {
    title: "Venus Noire",
    subtitle: "Historical Fiction",
    year: "2017",
    description:
      "The Most Beautiful Woman Who Ever Lived — a work of historical fiction.",
    cover: "/images/books/venus-noire.jpg",
    amazonUrl: searchUrl("Venus Noire"),
    genre: "Historical Fiction",
  },
  {
    title: "Che: The True Story",
    subtitle: "Historical Fiction / Biography",
    year: "2017",
    description:
      "A biography-based work of historical fiction.",
    cover: "/images/books/che-the-true-story.jpg",
    amazonUrl: searchUrl("Che The True Story"),
    genre: "Historical Fiction",
  },
  {
    title: "The Return of the Red Baron",
    subtitle: "Adventure",
    year: "2017",
    description:
      "An adventure novel from Lew Osteen.",
    cover: "/images/books/the-return-of-the-red-baron.jpg",
    amazonUrl: searchUrl("The Return of the Red Baron"),
    genre: "Historical Fiction",
  },
  {
    title: "Wigglewagglewattamus",
    subtitle: "The Hesitating Hippopotamus",
    year: "2017",
    description:
      "A whimsical children's tale about a hippopotamus who learns to make up his mind.",
    cover: "/images/books/wigglewagglewattamus.jpg",
    amazonUrl: searchUrl("Wigglewagglewattamus"),
    genre: "Children's",
  },
  {
    title: "The Little Rabbit",
    subtitle: "That Never Looked Up",
    year: "2017",
    description:
      "A charming children's story about a little rabbit who learns an important lesson.",
    cover: "/images/books/the-little-rabbit.jpg",
    amazonUrl: searchUrl("The Little Rabbit That never looked up"),
    genre: "Children's",
  },
  {
    title: "The Zodiac Cult Murders",
    subtitle: "Mystery",
    year: "2017",
    description:
      "A gripping mystery thriller. Paperback, 264 pages.",
    cover: "/images/books/the-zodiac-cult-murders.jpg",
    amazonUrl: searchUrl("The Zodiac Cult Murders"),
    genre: "Thriller",
  },
];
