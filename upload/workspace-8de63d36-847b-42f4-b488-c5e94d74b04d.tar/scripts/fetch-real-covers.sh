#!/bin/bash
# Fetch real Amazon book covers for Lew Osteen's back catalog.
# Uses the z-ai image-search CLI to find each cover, then downloads the best
# portrait-oriented result to public/images/books/<slug>.jpg.
#
# Skip files that already exist (idempotent) unless --force is passed.

OUT_DIR="/home/z/my-project/public/images/books"
mkdir -p "$OUT_DIR"
FORCE="${1:-}"

# slug|search-query pairs.
declare -a BOOKS=(
  "the-judgement|Lew Osteen The Judgement book cover"
  "the-cure|Lew Osteen The Cure book cover novel"
  "the-apocalypse-cometh|Lew Osteen The Apocalypse Cometh book cover"
  "wake-up-world|Lew Osteen Wake Up World Apocalypse Cometh book cover"
  "a-yellow-cotton-dress|Lew Osteen A Yellow Cotton Dress book cover"
  "six-notch-road|Lew Osteen Six Notch Road Joshua Trail book cover"
  "the-joshua-trail|Lew Osteen The Joshua Trail trilogy book cover"
  "a-season-of-reckoning|Lew Osteen A Season of Reckoning Joshua Trail book cover"
  "an-old-familiar-rain|Lew Osteen An Old Familiar Rain book cover"
  "venus-noire|Lew Osteen Venus Noire book cover"
  "che-the-true-story|Lew Osteen Che The True Story book cover"
  "the-return-of-the-red-baron|Lew Osteen The Return of the Red Baron book cover"
  "wigglewagglewattamus|Lew Osteen Wigglewagglewattamus hesitating hippopotamus children book"
  "the-little-rabbit|Lew Osteen The Little Rabbit That Never Looked Up children book"
  "the-zodiac-cult-murders|Lew Osteen The Zodiac Cult Murders book cover"
)

fetch_one() {
  local slug="$1"
  local query="$2"
  local out="$OUT_DIR/${slug}.jpg"

  if [ -z "$FORCE" ] && [ -f "$out" ] && [ "$(stat -c%s "$out" 2>/dev/null)" -gt 5000 ]; then
    echo "[skip] $slug already exists ($(stat -c%s "$out") bytes)"
    return
  fi

  echo "[search] $slug — $query"
  # Search with US region (Amazon.com covers), 3 results, no captioning for speed.
  local json
  json=$(z-ai image-search -q "$query" -c 3 --gl us --no-rank 2>/dev/null)
  if [ $? -ne 0 ]; then
    echo "[FAIL] $slug — search failed"
    return
  fi

  # Extract result URLs. Pick the most portrait-oriented one (height > width)
  # for a proper book cover aspect ratio. Fall back to the first result.
  local urls
  urls=$(echo "$json" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    if not data.get('success'):
        print(''); sys.exit(0)
    results = data.get('results', [])
    # Score each result: prefer portrait (height > width), higher res.
    scored = []
    for r in results:
        url = r.get('original_url', '')
        if not url: continue
        w = int((r.get('original_width') or '0').replace('px',''))
        h = int((r.get('original_height') or '0').replace('px',''))
        # Prefer portrait orientation for book covers
        portrait_bonus = 100 if h > w else 0
        # Prefer larger images
        size_bonus = min(w * h, 1000000) // 10000
        scored.append((portrait_bonus + size_bonus, url))
    scored.sort(reverse=True)
    print(scored[0][1] if scored else '')
except Exception as e:
    print('')
" 2>/dev/null)

  if [ -z "$urls" ]; then
    echo "[FAIL] $slug — no results"
    return
  fi

  # Download + optimize with sharp (resize to max 600w, JPEG quality 85).
  local tmp="/tmp/cover-${slug}.raw"
  curl -s -L -o "$tmp" "$urls" 2>/dev/null
  if [ ! -s "$tmp" ]; then
    echo "[FAIL] $slug — download failed"
    return
  fi

  bun -e "
const sharp = require('sharp');
const fs = require('fs');
const input = '$tmp';
const output = '$out';
sharp(input)
  .resize({ width: 600, height: 900, fit: 'cover', position: 'center' })
  .jpeg({ quality: 85, mozjpeg: true })
  .toFile(output)
  .then(info => { console.log('[ok]   $slug — ' + info.width + 'x' + info.height + ' (' + fs.statSync(output).size + ' bytes)'); })
  .catch(e => { console.error('[FAIL] $slug — sharp error: ' + e.message); process.exit(1); });
" 2>&1 | tail -1
  rm -f "$tmp"
}

# Run sequentially (image-search is slow + rate-limited).
for entry in "${BOOKS[@]}"; do
  slug="${entry%%|*}"
  query="${entry#*|}"
  fetch_one "$slug" "$query"
done
echo "=== done ==="
ls -la "$OUT_DIR" | tail -20
