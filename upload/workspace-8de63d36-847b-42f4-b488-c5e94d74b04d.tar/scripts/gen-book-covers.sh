#!/bin/bash
# Generate cinematic book covers for Lew Osteen's back catalog.
# Each prompt evokes the book's genre in the site's dark/gold cinematic style.
# Output: /home/z/my-project/public/images/books/<slug>.jpg

OUT_DIR="/home/z/my-project/public/images/books"
mkdir -p "$OUT_DIR"
SIZE="768x1344"  # portrait, closest to 2:3 book aspect

# Slug|prompt pairs. The prompt must NOT include the author's real name or
# copyrighted character names — only evocative scene descriptions.
declare -a BOOKS=(
  "the-judgement|dramatic thriller book cover, dark stormy sky over an empty grand courthouse, golden light through tall columns, scales of justice silhouetted, cinematic noir atmosphere, gold and charcoal palette, engraved serif title space at top, no text, no people"
  "the-cure|mysterious thriller book cover, a single glowing amber glass vial on a dark wooden table, dramatic single-source light, deep shadows, suspenseful medical thriller mood, gold and black palette, cinematic, no text, no people"
  "the-apocalypse-cometh|apocalyptic book cover, burning crimson sky over a silhouetted ruined city skyline, ash falling, ominous biblical atmosphere, ember red and gold palette, cinematic, no text, no people"
  "wake-up-world|apocalyptic book cover, blood-red dawn breaking over empty desert highway, lone road stretching to horizon, ominous storm clouds, prophecy mood, ember and dark gold palette, cinematic, no text, no people"
  "a-yellow-cotton-dress|historical fiction book cover, a single vintage yellow cotton dress on a wooden chair in a sunlit 19th century parlour, dust motes in light beam, sepia and gold tones, nostalgic atmospheric, cinematic, no text, no people"
  "six-notch-road|epic western book cover, rugged frontier trail through golden California gold country at dusk, lone rider silhouette on horseback, distant mountains, warm dust and amber sky, cinematic western, gold and earth palette, no text, no faces"
  "the-joshua-trail|epic western book cover, desert canyon trail at golden hour, dust kicked up on a dirt road, Joshua trees silhouette, lone rider distant, warm amber sky, cinematic frontier mood, gold and sand palette, no text, no faces"
  "a-season-of-reckoning|epic western book cover, tense frontier town main street at high noon, empty dusty street between wooden storefronts, dramatic long shadows, showdown atmosphere, gold and dust palette, cinematic western, no text, no people"
  "an-old-familiar-rain|mystery thriller book cover, vintage train carriage window at night with rain streaming down glass, warm interior lamp light, cold blue outside, spy vs spy mood, noir atmosphere, gold and indigo palette, no text, no faces"
  "venus-noire|historical fiction book cover, elegant black silhouette of a woman in profile against ornate art nouveau background, mysterious beauty, gold filigree, midnight blue and gold palette, cinematic, no text, no faces"
  "che-the-true-story|historical fiction biography book cover, misty jungle mountains at dawn, rugged South American landscape, distant campfire glow, atmospheric and contemplative, dark green and gold palette, cinematic, no text, no faces"
  "the-return-of-the-red-baron|adventure book cover, vintage red biplane soaring through dramatic sunset clouds, golden hour light, heroic aviation mood, sky and gold palette, cinematic adventure, no text, no people"
  "the-zodiac-cult-murders|thriller mystery book cover, giant glowing zodiac wheel carved into dark stone floor, candlelight, ominous cult symbols, shadows of robed figures, noir mystery mood, gold and charcoal palette, cinematic, no text, no faces"
  "wigglewagglewattamus|whimsical children book cover, a cute round purple hippopotamus sitting hesitantly at a riverbank, gentle watercolor storybook illustration, warm jungle background, friendly and soft, pastel gold and green palette, no text"
  "the-little-rabbit|whimsical children book cover, a small brown rabbit looking down at clover in a sunlit meadow, gentle watercolor storybook illustration, soft dappled light, warm and tender, pastel gold and green palette, no text"
)

GEN() {
  local slug="$1"
  local prompt="$2"
  local out="$OUT_DIR/${slug}.jpg"
  if [ -f "$out" ] && [ "$(stat -c%s "$out" 2>/dev/null)" -gt 5000 ]; then
    echo "[skip] $slug already exists"
    return
  fi
  z-ai image -p "$prompt" -o "$out" -s "$SIZE" >/dev/null 2>&1
  if [ $? -eq 0 ] && [ -f "$out" ]; then
    echo "[ok]   $slug ($(stat -c%s "$out") bytes)"
  else
    echo "[FAIL] $slug"
  fi
}

# Run in batches of 5 to avoid hammering the API.
BATCH=5
i=0
for entry in "${BOOKS[@]}"; do
  slug="${entry%%|*}"
  prompt="${entry#*|}"
  GEN "$slug" "$prompt" &
  i=$((i+1))
  if [ $((i % BATCH)) -eq 0 ]; then wait; fi
done
wait
echo "=== all done ==="
ls -la "$OUT_DIR"
